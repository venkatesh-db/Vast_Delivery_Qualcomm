#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; config="$(mktemp)"
target="/var/tmp/ubuntu-training-target"; mkdir -p "$target"; touch "$target/.ubuntu-labs-approved"
trap 'rm -f "$config"' EXIT
cat >"$config" <<EOF
TARGET_DIR=$target
IPERF_DURATION=2
DD_SIZE_MIB=32
CIFS_MODE=DRY_RUN
ARTIFACT_DIR=$PROJECT_DIR/artifacts
EOF
export UBUNTU_LABS_ENV="$config"
for script in 12-iperf3-network-test.sh 13-ethtool-interface-check.sh 14-dd-comparison.sh 15-cifs-mount-lab.sh 16-fstab-and-log-analysis.sh; do
  "$PROJECT_DIR/scripts/$script"
done
printf '\nUBUNTU LAB SUITE: PASS\n'

