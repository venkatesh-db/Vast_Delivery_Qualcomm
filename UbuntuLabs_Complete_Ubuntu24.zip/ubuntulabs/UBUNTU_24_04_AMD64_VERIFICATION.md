# Ubuntu 24.04 AMD64 verification

Tested on 2026-08-01 using the official `ubuntu:24.04` container image with platform `linux/amd64`.

## Commands executed

```bash
./scripts/00-install-tools.sh
./run-all-local.sh
./tests/verify-artifacts.sh
```

## Results

| Lab | Result | Evidence |
|---|---|---|
| iperf3 | PASS | Local loopback server/client completed; JSON showed positive receiver throughput |
| ethtool | PASS | Interface, counters, driver, link settings and selected error/drop statistics captured |
| dd | PASS | Bounded 32 MiB write/read completed and disposable file was removed |
| CIFS | PASS—dry-run | `mount.cifs` and installed `cifs-utils` package verified; no mount attempted |
| fstab/log analysis | PASS | Zero fstab parse errors; expected unreachable fixture paths documented; grep/awk assertions passed |
| Artifact verification | PASS | All five artifact families and expected values were found |

Final output:

```text
UBUNTU LAB SUITE: PASS
ARTIFACT VERIFICATION: PASS
```

## Boundaries

- Loopback iperf3 proves the executable workflow, not physical-network performance. Configure an approved remote `IPERF_SERVER` for a real path test.
- Container `ethtool` used a virtual Ethernet device; a real VM/physical client may expose different statistics.
- `dd` results are host/filesystem-specific and are not presented as VAST benchmarks.
- A kernel CIFS mount was not performed in the container. Real CIFS mode requires a privileged Ubuntu VM, an approved share and explicit safety gates.
- The fstab lab uses a fixture and never modifies `/etc/fstab`.
