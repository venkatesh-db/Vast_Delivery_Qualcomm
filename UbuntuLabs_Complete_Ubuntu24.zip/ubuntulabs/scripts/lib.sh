#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${UBUNTU_LABS_ENV:-$PROJECT_DIR/lab.env}"
[[ -f "$ENV_FILE" ]] && source "$ENV_FILE"
ARTIFACT_DIR="${ARTIFACT_DIR:-$PROJECT_DIR/artifacts}"
TARGET_DIR="${TARGET_DIR:-/var/tmp/ubuntu-training-target}"
mkdir -p "$ARTIFACT_DIR"
timestamp() { date -u +'%Y%m%dT%H%M%SZ'; }
info() { printf '[INFO] %s\n' "$*"; }
die() { printf '[ERROR] %s\n' "$*" >&2; exit 1; }
require_cmd() { command -v "$1" >/dev/null 2>&1 || die "Missing command: $1"; }
safe_target() {
  [[ -d "$TARGET_DIR" && -w "$TARGET_DIR" ]] || die "Target is not a writable directory: $TARGET_DIR"
  case "$TARGET_DIR" in /|/bin|/boot|/dev|/etc|/home|/lib|/lib64|/opt|/proc|/root|/run|/sbin|/srv|/sys|/usr|/var) die "Unsafe TARGET_DIR: $TARGET_DIR";; esac
  [[ -f "$TARGET_DIR/.ubuntu-labs-approved" ]] || die "Missing $TARGET_DIR/.ubuntu-labs-approved"
}

