#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; source "$SCRIPT_DIR/lib.sh"
require_cmd mount.cifs
mode="${CIFS_MODE:-DRY_RUN}"; out="$ARTIFACT_DIR/cifs-$(timestamp).txt"
if [[ "$mode" == "DRY_RUN" ]]; then
  {
    printf 'mount.cifs path: %s\n' "$(command -v mount.cifs)"
    if command -v dpkg-query >/dev/null 2>&1; then
      dpkg-query -W -f='cifs-utils version: ${Version}\n' cifs-utils
    else
      stat "$(command -v mount.cifs)"
    fi
    printf 'No mount attempted in DRY_RUN mode.\n'
  } | tee "$out"
  printf 'CIFS_DRY_RUN: PASS (tool available; no mount attempted)\n' | tee -a "$out"
  exit 0
fi
[[ "$mode" == "REAL" ]] || die "CIFS_MODE must be DRY_RUN or REAL"
[[ "${ALLOW_CIFS_MOUNT:-NO}" == "YES" ]] || die "Set ALLOW_CIFS_MOUNT=YES only for an approved training share"
[[ -n "${CIFS_SERVER:-}" && -n "${CIFS_SHARE:-}" ]] || die "Set CIFS_SERVER and CIFS_SHARE"
mountpoint="${CIFS_MOUNTPOINT:-/var/tmp/ubuntu-training-cifs}"
[[ -d "$mountpoint" && -f "$mountpoint/.ubuntu-cifs-lab-approved" ]] || die "Approved CIFS mountpoint/sentinel missing"
[[ -f "${CIFS_CREDENTIALS_FILE:-}" ]] || die "CIFS credentials file missing"
mode_bits="$(stat -c %a "$CIFS_CREDENTIALS_FILE")"; [[ "$mode_bits" == 600 || "$mode_bits" == 400 ]] || die "Credentials mode must be 600 or 400"
opts="credentials=$CIFS_CREDENTIALS_FILE,${CIFS_OPTIONS:-ro,vers=3.1.1}"
sudo mount -t cifs "//$CIFS_SERVER/$CIFS_SHARE" "$mountpoint" -o "$opts"
trap 'sudo umount "$mountpoint"' EXIT
findmnt -T "$mountpoint" | tee "$out"; timeout 10 find "$mountpoint" -maxdepth 1 -printf '%y %f\n' | head -n 50 | tee -a "$out"
sudo umount "$mountpoint"; trap - EXIT
printf 'CIFS_REAL_READONLY: PASS\n' | tee -a "$out"
