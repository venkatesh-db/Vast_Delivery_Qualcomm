#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; source "$SCRIPT_DIR/lib.sh"
require_cmd iperf3; require_cmd jq
duration="${IPERF_DURATION:-5}"; [[ "$duration" =~ ^[1-9][0-9]*$ ]] || die "IPERF_DURATION must be a positive integer"
server="${IPERF_SERVER:-127.0.0.1}"
run="$ARTIFACT_DIR/iperf3-$(timestamp)"; mkdir -p "$run"
if [[ "$server" == "127.0.0.1" || "$server" == "localhost" ]]; then
  iperf3 -s -1 -B 127.0.0.1 >"$run/server.log" 2>&1 & server_pid=$!
  trap 'kill "$server_pid" 2>/dev/null || true' EXIT
  for _ in {1..30}; do iperf3 -c 127.0.0.1 -t "$duration" -J >"$run/client.json" 2>"$run/client.err" && break; sleep 0.1; done
  wait "$server_pid"; trap - EXIT
else
  iperf3 -c "$server" -t "$duration" -J >"$run/client.json" 2>"$run/client.err"
fi
jq -e '.error == null and .end.sum_received.bits_per_second > 0' "$run/client.json" >/dev/null
jq '{receiver_Mbps:(.end.sum_received.bits_per_second/1000000), retransmits:(.end.sum_sent.retransmits // 0)}' "$run/client.json"
if [[ "$server" == "127.0.0.1" || "$server" == "localhost" ]]; then label=LOOPBACK; else label=REMOTE; fi
printf 'IPERF3_%s: PASS\nArtifacts: %s\n' "$label" "$run"
