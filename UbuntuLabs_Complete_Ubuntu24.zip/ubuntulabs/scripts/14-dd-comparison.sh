#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; source "$SCRIPT_DIR/lib.sh"
require_cmd dd; safe_target
size="${DD_SIZE_MIB:-64}"; [[ "$size" =~ ^[1-9][0-9]*$ ]] || die "DD_SIZE_MIB must be a positive integer"
[[ "$size" -le 1024 ]] || die "DD_SIZE_MIB is capped at 1024"
run="$ARTIFACT_DIR/dd-$(timestamp)"; mkdir -p "$run"; file="$TARGET_DIR/dd-training-${$}.bin"
cleanup() { rm -f -- "$file"; }; trap cleanup EXIT
dd if=/dev/zero of="$file" bs=1M count="$size" conv=fdatasync status=progress 2>"$run/sequential-write.txt"
dd if="$file" of=/dev/null bs=1M iflag=direct status=progress 2>"$run/sequential-read.txt"
[[ "$(stat -c %s "$file")" -eq $((size*1024*1024)) ]] || die "Unexpected test-file size"
cleanup; trap - EXIT
printf 'DD_DISPOSABLE_COMPARISON: PASS\nArtifacts: %s\n' "$run"

