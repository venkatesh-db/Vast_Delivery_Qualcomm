#!/usr/bin/env bash
set -Eeuo pipefail
if [[ "$(id -u)" -eq 0 ]]; then SUDO=(); else SUDO=(sudo); fi
"${SUDO[@]}" apt-get update
"${SUDO[@]}" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
  bash iperf3 ethtool fio sysstat tcpdump iproute2 cifs-utils smbclient \
  util-linux coreutils gawk grep jq python3
printf 'TOOLS: PASS\n'

