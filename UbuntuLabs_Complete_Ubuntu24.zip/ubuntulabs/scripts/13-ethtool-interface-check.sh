#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; source "$SCRIPT_DIR/lib.sh"
for c in ip ethtool; do require_cmd "$c"; done
iface="${LAB_IF:-$(ip route show default | awk 'NR==1 {for(i=1;i<=NF;i++) if($i=="dev") print $(i+1)}')}"
[[ -n "$iface" ]] || iface=lo
ip link show dev "$iface" >/dev/null || die "Interface not found: $iface"
out="$ARTIFACT_DIR/ethtool-$iface-$(timestamp).txt"
{
  printf 'UTC: %s\nInterface: %s\n\n' "$(date -u +%FT%TZ)" "$iface"
  ip -s link show dev "$iface"
  printf '\nDriver\n'; ethtool -i "$iface" 2>&1 || true
  printf '\nLink settings\n'; ethtool "$iface" 2>&1 || true
  printf '\nSelected statistics\n'; ethtool -S "$iface" 2>&1 | grep -Ei 'drop|discard|error|miss|timeout|reset' || true
} | tee "$out"
grep -q "Interface: $iface" "$out"
printf 'ETHTOOL_INSPECTION: PASS\nArtifacts: %s\n' "$out"
