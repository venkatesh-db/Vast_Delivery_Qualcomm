#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; source "$SCRIPT_DIR/lib.sh"
for c in findmnt grep awk journalctl; do require_cmd "$c"; done
fstab="$PROJECT_DIR/fixtures/fstab.training"; log="$PROJECT_DIR/fixtures/training.log"; run="$ARTIFACT_DIR/fstab-log-$(timestamp)"; mkdir -p "$run"
cp "$fstab" "$run/fstab.backup"
findmnt --verify --verbose --tab-file "$fstab" >"$run/fstab-verify.txt" 2>&1 || true
# The fixture intentionally references unmounted training paths, so reachability
# errors are expected. Syntax errors are not.
grep -q '^0 parse errors' "$run/fstab-verify.txt" || die "fstab fixture has parse errors"
grep -E 'WARN|ERROR' "$log" >"$run/warnings-errors.txt"
awk '{for(i=1;i<=NF;i++) if($i ~ /^latency_ms=/){split($i,a,"="); if(a[2]+0>max) max=a[2]+0}} END{print "max_latency_ms=" max}' "$log" >"$run/summary.txt"
awk '{for(i=1;i<=NF;i++) if($i ~ /^status=/){split($i,a,"="); count[a[2]]++}} END{for(s in count) print s "=" count[s]}' "$log" | sort >>"$run/summary.txt"
journalctl --utc --since '-5 min' --no-pager -n 100 >"$run/journal-last-5m.txt" 2>&1 || true
grep -q 'max_latency_ms=140' "$run/summary.txt"; grep -q 'status=denied' "$run/warnings-errors.txt"
printf 'FSTAB_LOG_ANALYSIS: PASS\nArtifacts: %s\n' "$run"
