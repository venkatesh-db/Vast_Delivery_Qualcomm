# Ubuntu troubleshooting labs

Five trainer-led labs for Ubuntu 24.04 clients:

| Lab | Script | Local verification | Real infrastructure requirement |
|---|---|---|---|
| Network throughput | `12-iperf3-network-test.sh` | Loopback client/server | Set up an approved remote iperf3 server for path testing |
| NIC inspection | `13-ethtool-interface-check.sh` | Active/default interface | Physical NIC exposes richer driver statistics |
| `dd` comparison | `14-dd-comparison.sh` | Disposable sentinel-protected directory | Use only an approved test filesystem |
| CIFS mount/authentication | `15-cifs-mount-lab.sh` | Tool/dry-run validation | Approved SMB share, mode-600 credentials and mount privilege |
| fstab and logs | `16-fstab-and-log-analysis.sh` | Included fixtures | Optional real journal review |

## Run on Ubuntu

```bash
cd ubuntulabs
chmod +x run-all-local.sh scripts/*.sh tests/*.sh
./scripts/00-install-tools.sh
./run-all-local.sh
./tests/verify-artifacts.sh
```

Expected ending:

```text
UBUNTU LAB SUITE: PASS
ARTIFACT VERIFICATION: PASS
```

## Safety boundaries

- `iperf3` uses loopback by default and does not test a real network path.
- `dd` writes only to a bounded disposable file beneath a directory containing `.ubuntu-labs-approved`, then deletes it.
- CIFS defaults to `DRY_RUN`. Real mounting requires `CIFS_MODE=REAL`, `ALLOW_CIFS_MOUNT=YES`, a sentinel-protected mountpoint and a credential file with mode 600/400.
- The fstab exercise validates a fixture and never edits `/etc/fstab`.
- Packet capture and `tc netem` remain in the earlier `vm-code-examples` package.

## Real CIFS configuration

Copy `lab.env.example` to `lab.env`, configure the approved share, and create the mountpoint gate:

```bash
sudo mkdir -p /var/tmp/ubuntu-training-cifs
sudo touch /var/tmp/ubuntu-training-cifs/.ubuntu-cifs-lab-approved
sudo chmod 600 /path/to/smb.credentials
```

The credentials file uses the standard format:

```text
username=training-user
password=customer-provided-password
domain=OPTIONAL-DOMAIN
```

Keep credentials outside the project and never commit them.

