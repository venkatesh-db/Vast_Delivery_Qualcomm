#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for file in "$PROJECT_DIR"/scripts/*.sh "$PROJECT_DIR"/run-all-local.sh; do bash -n "$file"; done
python3 - <<'PY' "$PROJECT_DIR/artifacts"
from pathlib import Path
import json, sys
p=Path(sys.argv[1])
assert any(json.loads(x.read_text())["end"]["sum_received"]["bits_per_second"] > 0 for x in p.glob("iperf3-*/client.json"))
assert any(p.glob("ethtool-*.txt"))
assert any(p.glob("dd-*/sequential-write.txt"))
assert any("CIFS_DRY_RUN: PASS" in x.read_text() for x in p.glob("cifs-*.txt"))
assert any("max_latency_ms=140" in x.read_text() for x in p.glob("fstab-log-*/summary.txt"))
print("ARTIFACT VERIFICATION: PASS")
PY

