#!/usr/bin/env bash
set -Eeuo pipefail
if [[ "$(id -u)" -eq 0 ]]; then SUDO=(); else command -v sudo >/dev/null 2>&1 || { echo 'ERROR: sudo is required' >&2; exit 1; }; SUDO=(sudo); fi
"${SUDO[@]}" apt-get update
"${SUDO[@]}" env DEBIAN_FRONTEND=noninteractive apt-get install -y bash python3 ca-certificates
python3 --version
printf 'INSTALL: PASS\n'
