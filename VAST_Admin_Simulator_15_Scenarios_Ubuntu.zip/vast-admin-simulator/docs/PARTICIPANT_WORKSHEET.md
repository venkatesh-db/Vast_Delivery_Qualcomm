# Incident worksheet

- Scenario:
- Business impact:
- Incident UTC:
- Baseline observation:
- Client-controlled evidence:
- Simulated VMS evidence:
- Real VAST evidence, if separately supplied:
- Hypothesis 1:
- Hypothesis 2:
- Hypothesis 3:
- Selected root cause and supporting evidence:
- Recovery action:
- Verification evidence:
- What remains unproven without a real VAST cluster:
