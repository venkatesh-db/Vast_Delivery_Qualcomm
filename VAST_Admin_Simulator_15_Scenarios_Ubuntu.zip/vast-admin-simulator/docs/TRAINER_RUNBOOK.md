# Trainer runbook

For each scenario, stop after `incident` and ask participants to write three hypotheses before revealing `diagnose`.

```bash
./bin/vast-sim phase SCENARIO baseline
./bin/vast-sim phase SCENARIO incident
./bin/vast-sim phase SCENARIO diagnose
./bin/vast-sim phase SCENARIO recover
./bin/vast-sim phase SCENARIO verify
```

Ask participants to identify:

1. the business symptom;
2. the evidence source and UTC;
3. whether each fact is `CLIENT_CONTROLLED`, `SIMULATED_VMS`, or real VAST evidence;
4. at least one alternative hypothesis;
5. the least-risk corrective action;
6. the evidence that proves recovery.

Do not reveal modeled VMS metrics as if they came from COSMOS/VMS. When real read-only VMS evidence is available, compare it in a separate window and preserve provenance.
