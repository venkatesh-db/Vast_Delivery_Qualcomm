# Production-readiness statement

## What is production-ready

- deterministic training state machine;
- bounded and isolated Ubuntu workloads;
- path-containment checks;
- per-scenario execution locks;
- atomic JSON state/evidence writes;
- UTC timestamps and schema versions;
- explicit evidence provenance;
- automated unit, safety and end-to-end tests;
- idempotent recovery probes.

## What is not production automation

The simulator does not connect to or administer VAST. It must not be used to change Views, policies, quotas, snapshots, replication, hardware state, alerts or software versions. Those actions require official version-matched VAST procedures, customer authorization and a non-production change plan.

## Acceptance gates before training

1. Run `tests/run-tests.sh` on the final Ubuntu VM.
2. Run `run-all.sh` and require `15/15` PASS.
3. Confirm the lab root is disposable and has at least 100 MiB available.
4. Review the evidence labels with participants.
5. If demonstrating real VAST, use a separate read-only integration and keep its artifacts distinct.
