# Scenario catalog and evidence boundaries

| # | Incident | Ubuntu-controlled evidence | Simulated VMS evidence | Real VAST validation required |
|---:|---|---|---|---|
| 1 | GPU starvation | Bounded file-read throughput | View throughput, latency, GPU teaching signal | Analytics and workload metrics |
| 2 | Hot dataset | Bounded read probe | View concurrency and tail latency | Per-View Analytics |
| 3 | Small files | Real creation/list/stat of up to 500 files | Modeled five-thousand-entry pressure | Namespace metrics |
| 4 | Policy block | Controlled EACCES outcome | View-policy denial | Export/View policy and event |
| 5 | Missing host | Controlled rejected-host outcome | Allow-list state | Real client address policy |
| 6 | Auth/flavor | Controlled authentication outcome | Provider/security-flavor mismatch | AD/LDAP and View settings |
| 7 | Quota full | Bounded logical EDQUOT outcome | View quota utilization | Real quota and checkpoint test |
| 8 | Capacity creep | None | Capacity/snapshot accounting | VMS capacity and snapshot data |
| 9 | Retention | None | Retention policy timeline | Snapshot policy and recovery points |
| 10 | Wrong version | Real symlink and manifest mismatch | Dataset/View mapping | Real mounted path/snapshot |
| 11 | Replication lag | Bounded source/target copy backlog | Replication lag/RPO | Real replication status |
| 12 | Drive rebuild | None | Alarm and rebuild progress | VMS hardware state/VAST Support |
| 13 | Node/NIC failover | Userspace socket delay | Path loss and failover state | VIP/path and hardware events |
| 14 | Link degradation | Userspace socket delay | Loss/latency metrics | Approved iperf/tcpdump/VMS metrics |
| 15 | Upgrade coordination | None | Precheck/change-window state | Authorized non-production upgrade |

## Production use rule

Never use simulator output as a customer incident record or evidence of actual VAST health. Replace `SIMULATED_VMS` evidence with authenticated VMS exports before making a production conclusion.
