#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
lab_root="${VAST_SIM_LAB_ROOT:-/var/tmp/vast-admin-simulator}"
mkdir -p "$lab_root"
touch "$lab_root/.vast-admin-simulator-approved"
exec "$PROJECT_DIR/bin/vast-sim" --lab-root "$lab_root" run-all
