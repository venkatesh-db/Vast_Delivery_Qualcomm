# Ubuntu 24.04 AMD64 acceptance report

- Test date: 2026-08-01
- Image: official `ubuntu:24.04`
- Platform: `linux/amd64`
- Python: 3.12.3
- Container exit code: 0

## Executed

```bash
./install-ubuntu.sh
./tests/run-tests.sh
VAST_SIM_LAB_ROOT=/var/tmp/vast-admin-simulator-e2e \
VAST_SIM_ARTIFACTS=/var/tmp/vast-admin-simulator-artifacts \
./run-all.sh
```

## Automated tests

| Test | Result |
|---|---|
| Broad/root path rejection | PASS |
| Symlink/path escape rejection | PASS |
| Exactly 15 unique scenario definitions | PASS |
| Out-of-order state transition rejection | PASS |
| All scenario state machines reach verified PASS | PASS |
| Physical metadata workload remains bounded | PASS |

Unit/safety result:

```text
Ran 6 tests
OK
TEST SUITE: PASS
```

End-to-end result:

```text
SCENARIO 01: PASS
SCENARIO 02: PASS
SCENARIO 03: PASS
SCENARIO 04: PASS
SCENARIO 05: PASS
SCENARIO 06: PASS
SCENARIO 07: PASS
SCENARIO 08: PASS
SCENARIO 09: PASS
SCENARIO 10: PASS
SCENARIO 11: PASS
SCENARIO 12: PASS
SCENARIO 13: PASS
SCENARIO 14: PASS
SCENARIO 15: PASS
ALL SCENARIOS: PASS (15/15)
```

## Acceptance boundary

This certifies the Ubuntu training simulator code and its controlled workloads. It does not certify compatibility with a customer VAST release and does not validate any real View, policy, quota, snapshot, replication, hardware, alert or upgrade operation. Every modeled management artifact is labeled `SIMULATED_VMS` and `NOT_CONNECTED` to real VAST.
