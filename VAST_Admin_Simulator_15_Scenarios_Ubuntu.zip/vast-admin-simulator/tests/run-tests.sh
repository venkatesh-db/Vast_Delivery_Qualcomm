#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for file in "$PROJECT_DIR"/bin/* "$PROJECT_DIR"/*.sh "$PROJECT_DIR"/tests/*.sh; do bash -n "$file"; done
export PYTHONPATH="$PROJECT_DIR/src"
python3 -m compileall -q "$PROJECT_DIR/src"
python3 -m unittest discover -s "$PROJECT_DIR/tests" -p 'test_*.py' -v
printf 'TEST SUITE: PASS\n'
