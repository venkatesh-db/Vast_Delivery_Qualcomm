import json
import tempfile
import unittest
from pathlib import Path

from vast_admin_sim.engine import PHASES, ScenarioError, Simulator
from vast_admin_sim.safety import SafetyError, guarded_child, validate_lab_root


PROJECT = Path(__file__).resolve().parents[1]


class SafetyTests(unittest.TestCase):
    def test_rejects_broad_roots(self):
        for path in (Path("/"), Path("/etc"), Path("/var")):
            with self.assertRaises(SafetyError):
                validate_lab_root(path)

    def test_rejects_path_escape(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            with self.assertRaises(SafetyError):
                guarded_child(root, root / ".." / "escape")


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        base = Path(self.temp.name)
        self.sim = Simulator(PROJECT, base / "lab", base / "artifacts")

    def tearDown(self):
        self.temp.cleanup()

    def test_exactly_fifteen_scenarios(self):
        self.assertEqual(sorted(self.sim.scenarios), list(range(1, 16)))

    def test_out_of_order_phase_rejected(self):
        with self.assertRaises(ScenarioError):
            self.sim.run_phase(1, "incident")

    def test_every_scenario_reaches_verified_pass(self):
        for scenario_id in range(1, 16):
            run, evidence = self.sim.run_scenario(scenario_id)
            state = json.loads((run / "state.json").read_text())
            self.assertEqual(state["completed"], list(PHASES))
            self.assertEqual(state["status"], "PASS")
            self.assertEqual(evidence["evidence_labels"]["management"], "SIMULATED_VMS")
            self.assertEqual(evidence["evidence_labels"]["real_vast"], "NOT_CONNECTED")
            self.assertTrue((run / "summary.md").exists())

    def test_bounded_physical_workload(self):
        run, _ = self.sim.run_scenario(3)
        incident = json.loads((run / "incident.json").read_text())
        self.assertLessEqual(incident["ubuntu_probe"]["physical_entries"], 500)
        self.assertEqual(incident["ubuntu_probe"]["modeled_entries"], 5000)


if __name__ == "__main__":
    unittest.main()
