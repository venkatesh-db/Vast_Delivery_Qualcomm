import argparse
import json
import os
import sys
from pathlib import Path

from .engine import PHASES, ScenarioError, Simulator
from .safety import SafetyError


def project_dir():
    return Path(__file__).resolve().parents[2]


def parser():
    p = argparse.ArgumentParser(prog="vast-sim", description="Safe VAST administration training simulator")
    p.add_argument("--lab-root", type=Path, default=Path(os.environ.get("VAST_SIM_LAB_ROOT", "/var/tmp/vast-admin-simulator")))
    p.add_argument("--artifacts", type=Path, default=None)
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("list")
    run = sub.add_parser("run"); run.add_argument("scenario", type=int)
    phase = sub.add_parser("phase"); phase.add_argument("scenario", type=int); phase.add_argument("phase", choices=PHASES)
    sub.add_parser("run-all")
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    project = project_dir()
    artifacts = args.artifacts or Path(os.environ.get("VAST_SIM_ARTIFACTS", project / "artifacts"))
    try:
        sim = Simulator(project, args.lab_root, artifacts)
        if args.command == "list":
            for sid, item in sorted(sim.scenarios.items()):
                print(f"{sid:02d}  {item['category']:<11} {item['title']}")
            return 0
        if args.command == "phase":
            run, evidence = sim.run_phase(args.scenario, args.phase)
            print(json.dumps({"status": "PASS", "phase": args.phase, "run": str(run),
                              "labels": evidence["evidence_labels"]}, indent=2))
            return 0
        if args.command == "run":
            run, _ = sim.run_scenario(args.scenario)
            print(f"SCENARIO {args.scenario:02d}: PASS\nRun: {run}")
            return 0
        passed = []
        for scenario_id in sorted(sim.scenarios):
            run, _ = sim.run_scenario(scenario_id)
            passed.append({"scenario": scenario_id, "status": "PASS", "run": str(run)})
            print(f"SCENARIO {scenario_id:02d}: PASS")
        print(f"\nALL SCENARIOS: PASS ({len(passed)}/15)")
        return 0
    except (ScenarioError, SafetyError, OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
