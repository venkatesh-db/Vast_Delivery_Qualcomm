from pathlib import Path


class SafetyError(RuntimeError):
    pass


FORBIDDEN = {Path("/"), Path("/etc"), Path("/home"), Path("/root"), Path("/usr"), Path("/var")}


def validate_lab_root(path: Path) -> Path:
    requested = path.expanduser().absolute()
    resolved = path.expanduser().resolve()
    forbidden_resolved = {item.resolve() for item in FORBIDDEN}
    if requested in FORBIDDEN or resolved in forbidden_resolved or len(resolved.parts) < 3:
        raise SafetyError(f"unsafe lab root: {resolved}")
    resolved.mkdir(parents=True, exist_ok=True)
    marker = resolved / ".vast-admin-simulator-approved"
    if not marker.exists():
        marker.touch(mode=0o600)
    if not marker.is_file():
        raise SafetyError(f"invalid safety marker: {marker}")
    return resolved


def guarded_child(root: Path, child: Path) -> Path:
    # Resolve the parent to catch symlink escapes, but preserve the final path
    # component so an in-root symlink can itself be inspected or replaced.
    candidate = child.parent.resolve() / child.name
    try:
        candidate.relative_to(root.resolve())
    except ValueError as exc:
        raise SafetyError(f"path escapes lab root: {candidate}") from exc
    return candidate
