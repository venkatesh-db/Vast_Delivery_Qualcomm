import fcntl
import json
import uuid
from pathlib import Path

from .io_utils import atomic_json, utc_now
from .safety import guarded_child, validate_lab_root
from .workloads import execute

PHASES = ("baseline", "incident", "diagnose", "recover", "verify")


class ScenarioError(RuntimeError):
    pass


class Simulator:
    def __init__(self, project: Path, lab_root: Path, artifact_root: Path):
        self.project = project.resolve()
        self.lab_root = validate_lab_root(lab_root)
        self.artifact_root = artifact_root.resolve()
        self.artifact_root.mkdir(parents=True, exist_ok=True)
        config = json.loads((self.project / "config/scenarios.json").read_text(encoding="utf-8"))
        if config.get("schema_version") != 1 or len(config.get("scenarios", [])) != 15:
            raise ScenarioError("scenario configuration must use schema 1 and contain 15 scenarios")
        ids = [item.get("id") for item in config["scenarios"]]
        if sorted(ids) != list(range(1, 16)) or len(set(ids)) != 15:
            raise ScenarioError("scenario IDs must be unique integers 1 through 15")
        required = {"slug", "title", "category", "adapter", "root_cause", "symptom", "baseline", "incident"}
        valid_adapters = {"throughput", "metadata", "access", "quota", "version", "replication", "network", "simulated"}
        for item in config["scenarios"]:
            missing = required.difference(item)
            if missing or item["adapter"] not in valid_adapters:
                raise ScenarioError(f"invalid scenario {item.get('id')}: missing={sorted(missing)} adapter={item.get('adapter')}")
        self.scenarios = {int(item["id"]): item for item in config["scenarios"]}

    def scenario(self, scenario_id: int):
        try:
            return self.scenarios[int(scenario_id)]
        except KeyError as exc:
            raise ScenarioError(f"unknown scenario: {scenario_id}") from exc

    def _pointer(self, scenario_id):
        return self.artifact_root / f".current-{scenario_id:02d}"

    def _new_run(self, scenario):
        run_id = f"{utc_now().replace(':','').replace('-','')}-{uuid.uuid4().hex[:8]}"
        run = self.artifact_root / f"scenario-{scenario['id']:02d}-{scenario['slug']}" / run_id
        run.mkdir(parents=True)
        self._pointer(scenario["id"]).write_text(str(run), encoding="utf-8")
        return run

    def _current_run(self, scenario):
        pointer = self._pointer(scenario["id"])
        if not pointer.exists():
            raise ScenarioError("run baseline first")
        run = Path(pointer.read_text(encoding="utf-8").strip()).resolve()
        try:
            run.relative_to(self.artifact_root)
        except ValueError as exc:
            raise ScenarioError("invalid run pointer") from exc
        return run

    def run_phase(self, scenario_id: int, phase: str):
        if phase not in PHASES:
            raise ScenarioError(f"invalid phase: {phase}")
        scenario = self.scenario(scenario_id)
        lock_path = self.artifact_root / f".scenario-{scenario_id:02d}.lock"
        with lock_path.open("w") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            run = self._new_run(scenario) if phase == "baseline" else self._current_run(scenario)
            state_path = run / "state.json"
            state = json.loads(state_path.read_text()) if state_path.exists() else {"completed": []}
            expected = PHASES[len(state["completed"])] if len(state["completed"]) < len(PHASES) else None
            if phase != expected:
                raise ScenarioError(f"expected phase {expected}; received {phase}")
            evidence = self._evidence(scenario, phase, run)
            atomic_json(run / f"{phase}.json", evidence)
            state["completed"].append(phase); state["scenario_id"] = scenario_id
            state["status"] = "PASS" if phase == "verify" else "IN_PROGRESS"
            state["updated_utc"] = utc_now()
            atomic_json(state_path, state)
            if phase == "verify":
                self._report(scenario, run)
            return run, evidence

    def _evidence(self, scenario, phase, run):
        workload_root = guarded_child(self.lab_root, self.lab_root / f"scenario-{scenario['id']:02d}")
        workload_root.mkdir(exist_ok=True)
        if phase in ("baseline", "incident"):
            probe = execute(scenario["adapter"], workload_root, phase)
            modeled = scenario[phase]
            conclusion = scenario["symptom"] if phase == "incident" else "Healthy baseline captured"
        elif phase == "diagnose":
            probe = {"hypotheses": [scenario["root_cause"], "Client resource contention", "Network path impairment"],
                     "selected": scenario["root_cause"], "method": "correlate client and VMS evidence in UTC"}
            modeled = scenario["incident"]; conclusion = f"Root cause identified: {scenario['root_cause']}"
        elif phase == "recover":
            probe = execute(scenario["adapter"], workload_root, "recovered")
            modeled = scenario["baseline"]; conclusion = "Controlled fault removed; modeled management state restored"
        else:
            incident = json.loads((run / "incident.json").read_text())
            recovered = json.loads((run / "recover.json").read_text())
            probe = {"incident_present": bool(incident), "recovery_present": bool(recovered),
                     "required_phases": [p for p in PHASES[:-1]], "verification": "PASS"}
            modeled = scenario["baseline"]; conclusion = "Recovery evidence matches the expected healthy state"
        return {"schema_version": 1, "scenario_id": scenario["id"], "slug": scenario["slug"],
                "title": scenario["title"], "category": scenario["category"], "phase": phase,
                "utc": utc_now(), "evidence_labels": {"client": "CLIENT_CONTROLLED",
                "management": "SIMULATED_VMS", "real_vast": "NOT_CONNECTED"},
                "modeled_vms_metrics": modeled, "ubuntu_probe": probe, "conclusion": conclusion,
                "production_boundary": "No real VAST configuration or hardware operation was performed"}

    def _report(self, scenario, run):
        lines = [f"# Scenario {scenario['id']}: {scenario['title']}", "",
                 f"- Category: `{scenario['category']}`", f"- Root cause: {scenario['root_cause']}",
                 "- VAST evidence: `SIMULATED_VMS`", "- Real VAST connected: `NO`", "",
                 "| Phase | UTC | Conclusion |", "|---|---|---|"]
        for phase in PHASES:
            data = json.loads((run / f"{phase}.json").read_text())
            lines.append(f"| {phase} | {data['utc']} | {data['conclusion']} |")
        lines += ["", "## Verification", "", "**PASS** — baseline, incident, diagnosis, recovery and verification evidence were generated in order.", "",
                  "> This is a training simulation. It is not evidence from a real VAST cluster."]
        (run / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    def run_scenario(self, scenario_id):
        result = None
        for phase in PHASES:
            result = self.run_phase(scenario_id, phase)
        return result
