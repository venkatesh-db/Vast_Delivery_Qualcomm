import errno
import hashlib
import os
import shutil
import socket
import time
from pathlib import Path

from .safety import guarded_child


def _dataset(root: Path) -> Path:
    path = guarded_child(root, root / "dataset.bin")
    if not path.exists() or path.stat().st_size != 4 * 1024 * 1024:
        block = bytes((i % 251 for i in range(1024 * 1024)))
        with path.open("wb") as handle:
            for _ in range(4):
                handle.write(block)
            handle.flush()
            os.fsync(handle.fileno())
    return path


def throughput(root: Path, phase: str):
    data = _dataset(root)
    start = time.monotonic()
    digest = hashlib.sha256()
    with data.open("rb") as handle:
        while chunk := handle.read(256 * 1024):
            digest.update(chunk)
            if phase == "incident":
                time.sleep(0.004)
    elapsed = max(time.monotonic() - start, 0.000001)
    return {"real_probe": "bounded_file_read", "bytes": data.stat().st_size,
            "elapsed_seconds": round(elapsed, 6),
            "measured_mib_s": round(data.stat().st_size / 1048576 / elapsed, 2),
            "sha256": digest.hexdigest()}


def metadata(root: Path, phase: str):
    directory = guarded_child(root, root / "small-files")
    directory.mkdir(exist_ok=True)
    desired = 100 if phase != "incident" else 500
    for index in range(desired):
        path = directory / f"sample-{index:04d}.dat"
        if not path.exists():
            path.write_text(f"record={index}\n", encoding="utf-8")
    if desired == 100:
        for path in sorted(directory.glob("sample-*.dat"))[desired:]:
            path.unlink()
    start = time.monotonic()
    total = 0
    for path in directory.iterdir():
        total += path.stat().st_size
        if phase == "incident":
            time.sleep(0.0001)
    elapsed = time.monotonic() - start
    return {"real_probe": "list_and_stat", "physical_entries": desired,
            "modeled_entries": 100 if phase != "incident" else 5000,
            "bytes": total, "elapsed_seconds": round(elapsed, 6)}


def access(root: Path, phase: str):
    path = guarded_child(root, root / "access-probe.txt")
    path.write_text("training data\n", encoding="utf-8")
    if phase == "incident":
        return {"controlled_client_result": "EACCES", "errno": errno.EACCES,
                "note": "policy outcome modeled locally; no real export changed"}
    return {"controlled_client_result": "read_ok", "bytes": len(path.read_bytes())}


def quota(root: Path, phase: str):
    path = guarded_child(root, root / "checkpoint.bin")
    logical_cap = 1024 * 1024
    requested = 512 * 1024 if phase != "incident" else 2 * 1024 * 1024
    if requested > logical_cap:
        return {"controlled_client_result": "EDQUOT", "errno": errno.EDQUOT,
                "logical_cap_bytes": logical_cap, "requested_bytes": requested,
                "physical_bytes_written": 0}
    path.write_bytes(b"Q" * requested)
    return {"controlled_client_result": "checkpoint_ok", "physical_bytes_written": requested}


def version(root: Path, phase: str):
    versions = guarded_child(root, root / "versions")
    versions.mkdir(exist_ok=True)
    for name in ("v7", "v8"):
        d = versions / name
        d.mkdir(exist_ok=True)
        (d / "MANIFEST").write_text(f"dataset_version={name}\n", encoding="utf-8")
    current = guarded_child(root, root / "current")
    if current.is_symlink() or current.exists():
        current.unlink()
    mounted = "v7" if phase == "incident" else "v8"
    current.symlink_to(versions / mounted, target_is_directory=True)
    manifest = (current / "MANIFEST").read_text(encoding="utf-8").strip()
    return {"real_probe": "symlink_manifest", "expected": "v8", "mounted": mounted,
            "manifest": manifest, "match": mounted == "v8"}


def replication(root: Path, phase: str):
    source = guarded_child(root, root / "replication-source")
    target = guarded_child(root, root / "replication-target")
    source.mkdir(exist_ok=True); target.mkdir(exist_ok=True)
    for i in range(8):
        (source / f"object-{i}.dat").write_text(f"object={i}\n", encoding="utf-8")
    copy_count = 2 if phase == "incident" else 8
    for path in list(sorted(source.iterdir()))[:copy_count]:
        shutil.copy2(path, target / path.name)
    pending = len(list(source.iterdir())) - len(list(target.iterdir()))
    return {"real_probe": "bounded_replication_copy", "source_objects": 8,
            "copied_objects": len(list(target.iterdir())), "pending_objects": pending}


def network(root: Path, phase: str):
    left, right = socket.socketpair()
    try:
        start = time.monotonic()
        left.sendall(b"vast-training-probe")
        payload = right.recv(64)
        if phase == "incident":
            time.sleep(0.03)
        right.sendall(payload)
        left.recv(64)
        elapsed = (time.monotonic() - start) * 1000
    finally:
        left.close(); right.close()
    return {"real_probe": "userspace_socket_roundtrip", "roundtrip_ms": round(elapsed, 3),
            "controlled_delay_ms": 30 if phase == "incident" else 0}


ADAPTERS = {"throughput": throughput, "metadata": metadata, "access": access,
            "quota": quota, "version": version, "replication": replication,
            "network": network}


def execute(adapter: str, root: Path, phase: str):
    if adapter == "simulated":
        return {"real_probe": None, "note": "management-plane evidence is simulated"}
    return ADAPTERS[adapter](root, phase)
