# VAST Admin Simulator — 15 production-incident labs

A safe Ubuntu 24.04 training simulator for practicing incident workflow when a real VAST management sandbox is unavailable.

## Critical boundary

This project is production-quality **training software**, not production VAST automation. It never creates or changes real Views, policies, quotas, snapshots, exports, alerts, hardware, replication or software upgrades. Management-plane evidence is always labeled `SIMULATED_VMS`; Ubuntu workload evidence is labeled `CLIENT_CONTROLLED`.

## Requirements

- Ubuntu 24.04
- Python 3.10 or newer
- Bash 5
- approximately 100 MiB free beneath `/var/tmp`

No third-party Python packages are required.

## Quick start

```bash
cd vast-admin-simulator
chmod +x bin/vast-sim install-ubuntu.sh run-all.sh tests/*.sh
./install-ubuntu.sh
./bin/vast-sim list
./bin/vast-sim run 1
./run-all.sh
./tests/run-tests.sh
```

Expected ending:

```text
ALL SCENARIOS: PASS (15/15)
TEST SUITE: PASS
```

## Trainer-led phase mode

Run each phase separately so participants investigate before seeing the answer:

```bash
./bin/vast-sim phase 1 baseline
./bin/vast-sim phase 1 incident
./bin/vast-sim phase 1 diagnose
./bin/vast-sim phase 1 recover
./bin/vast-sim phase 1 verify
```

The simulator refuses out-of-order phases.

## Scenario coverage

1. GPU-feeding slowdown
2. Hot-dataset latency
3. Small-file metadata slowness
4. View-policy access block
5. New host absent from allow-list
6. Identity/security-flavor mismatch
7. Quota-full checkpoint
8. Capacity creep
9. Snapshot-retention error
10. Wrong dataset version
11. Replication lag
12. Drive failure/rebuild
13. Node/NIC failover
14. Network-link degradation
15. Upgrade coordination

See `docs/SCENARIO_CATALOG.md` for evidence type and real-VAST boundaries.

## Safety

- Writes are confined to a validated lab root and artifact directory.
- The lab root must contain `.vast-admin-simulator-approved`; the runner creates it only beneath the explicit lab root.
- Workloads are bounded: 4 MiB dataset, at most 500 physical metadata files and a 1 MiB logical quota probe.
- No `sudo`, mount, packet impairment, service control or network reconfiguration is used.
- State files are atomic and scenario execution is locked.
- All artifacts use JSON schema version 1 and UTC timestamps.
